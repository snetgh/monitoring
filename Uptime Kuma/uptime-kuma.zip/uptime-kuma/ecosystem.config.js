module.exports = {
    apps: [{
        name: "uptime-kuma",
        script: "./server/server.js",
    }]
};
